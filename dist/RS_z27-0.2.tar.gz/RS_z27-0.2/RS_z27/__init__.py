from .algoritms import *

__author__ = 'SergKornev'
__version__ = '0.0'
__email__ = 'sergeyroot77@gmail.com'