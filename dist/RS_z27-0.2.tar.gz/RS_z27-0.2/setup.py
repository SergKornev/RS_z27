from setuptools import setup

setup(name='RS_z27',
      version='0.2',
      description='Recommend System',
      packages=['RS_z27'],
      author_email='sergeyroot77@gmail.com',
      zip_safe=False)